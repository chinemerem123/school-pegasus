AOS.init();

let add=document.querySelector(".float-add");
let more=document.querySelector("#more");

add.addEventListener('click',()=>{
    more.style.display="flex";
})